####false reviews


range(data.predict$PC6)
#top and botton 100 false reviews
print(data.predict[data.predict$PC6>=2.37, c(1,6,8:12,24)])
print(data.predict[data.predict$PC6<=-2.58, c(1,6,8:12,24)])

#top and botton 50 false reviews
print(data.predict[data.predict$PC6>=2.5876, c(1,6,8:12,24)])
print(data.predict[data.predict$PC6<=-2.79, c(1,6,8:12,24)])


#the top and bottom 20 - ie 40 false reviews
print(data.predict[data.predict$PC6>=2.7775, c(1,6,8:12,24)])
print(data.predict[data.predict$PC6<=-3.1, c(1,6,8:12,24)])


#20 at each end of false reviews
false<-rbind(data.predict[data.predict$PC6>=2.7775, c(1,6,8:24)],data.predict[data.predict$PC6<=-3.1, c(1,6,8:24)])
#50 at each end of false reviews
false<-rbind(data.predict[data.predict$PC6>=2.5876, c(1,6,8:24)], data.predict[data.predict$PC6<=-2.79, c(1,6,8:24)])
#100 at eacg end of false reviews
false<-rbind(data.predict[data.predict$PC6>=2.37, c(1,6,8:24)],data.predict[data.predict$PC6<=-2.58, c(1,6,8:24)])
names(false)


#who has done more than 1 false review?
false.rows<-false$profileName
length(unique(false$profileName))
(sort(table(false$profileName), decreasing=T))[1:14]

#plotting
plot(data.predict$PC6[1:1000000], data.predict$rating[1:1000000], ylab="Overall Rating", cex.main=2, 
     xlab="PC6 Score", cex.lab=2, main="False Reviews", col="darkblue")
points(false$PC6, false$rating, col=2, pch=19)


#qplot of PC1:rating scores, coloured by PC6 score
qplot(data.predict$PC1[1:500000],data.predict$rating[1:500000], col=abs(data.predict$PC6[1:500000]), xlab="PC1 Score",
      ylab="Overall Rating", size=8)+
  (scale_colour_gradient(low="pink", high="navy")) +
  theme(axis.text=element_text(size=30),
             axis.title=element_text(size=30,face="bold"),legend.text=element_text(size=30), legend.title=element_text(size=30)) + guides(size=FALSE) + 
  guides(color=guide_legend(title="PC 6 Score", title.hjust=0.7, override.aes=list(size=10)))



