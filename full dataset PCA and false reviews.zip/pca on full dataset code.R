####PCA on FULL dataset

#scaling
scaled<-scale(beer.data[,c(6, 8:12)])
colnames(scaled)<-c("ABV.scaled", "Appearance.scaled", "Aroma.scaled", "Palate.scaled", "Taste.scaled", "rating.scaled")
scaled.data<-cbind(beer.data, scaled)
names(scaled.data)

#PCA with and without overall rating
pca.full<-prcomp(scaled.data[,13:18])
pca.4ratings<-prcomp(scaled.data[,13:17])

#predicitions
predictions<-predict(pca.4ratings, scaled.data[,13:17])
predictions<-predict(pca.full, scaled.data[,13:18])
data.predict<-cbind(scaled.data, predictions)

#assessment
eigen(cov(scaled.data[,13:17]))
eigen(cov(scaled.data[,13:18]))
plot(data.predict$PC1,data.predict$PC2)
summary(pca.4ratings)
summary(pca.full2)
par(mfrow=c(1,1))
plot(data.predict$PC1[1:100000], data.predict$rating[1:100000], ylab="Overall Rating", 
     xlab="PC1 Score", cex.lab=2, cex.main=2, main="Overall Beer Rating Against Score \n on Principal Component 1", col="darkblue")
lm1<-lm(data.predict$rating[1:1000000]~data.predict$PC1[1:1000000])
abline(lm1, col=2, lwd=3)
cor(data.predict$PC1, data.predict$rating)
par(mar=c(5,6,5,2))
par(mfrow=c(1,1))
screeplot(pca.full, typ="l", main="Screeplot of Principal Component Eigenvalues\n for the Full Dataset",
          cex=1.5, cex.lab=2, cex.main=1.8, lwd=2)

screeplot(pca.4ratings, typ="l", main="Screeplot of Principal Component Eigenvalues\n for the Full Dataset - Excluding Overall Rating",
          cex=1.5, cex.lab=2, cex.main=1.8, lwd=2)

cor(data.predict$PC1, data.predict$rating)

par(mfrow=c(1,1))
plot(data.predict$PC1[1:100000], data.predict$rating[1:100000], ylab="Overall Rating", cex.main=2, 
     xlab="PC1 Score", cex.lab=2, main="Overall Beer Rating Against Score \n on Principal Component 1", col="darkblue")
lm1<-lm(data.predict$rating[1:1000000]~data.predict$PC1[1:1000000])
abline(lm1, col=2, lwd=3)




